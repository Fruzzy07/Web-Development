export interface Product {
  id: number;
  name: string;
  image: string;
  images: string[];
  price: number;
  description: string;
  rating: number;
  category: string;
  link: string;
  IsShown: boolean;
  likeCount: number;
}

export const products = [
  {
    id: 1,
    name: 'Electric kettle BEREKE BR-810 grey',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h08/hde/80282292781086.jpg?format=gallery-large',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h08/hde/80282292781086.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h08/hde/80282292781086.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h08/hde/80282292781086.jpg?format=gallery-medium',
    ],
    price: 1748,
    description:
      'Descaling filter: No, Type:electric kettle, volume: 2.0L, Power: 1500.0W, Case material: Stainless steel, Color: Grey',
    rating: 5,
    category: 'Appliances',
    link: 'https://kaspi.kz/shop/p/elektrochainik-bereke-br-810-seryi-109981423/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 2,
    name: 'Kitchen scales Generic SF-400',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h47/ha1/64094073815070.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hcf/ha8/64094074798110.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h5a/h8f/64094077124638.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h47/ha1/64094073815070.jpg?format=gallery-medium',
    ],
    price: 799,
    description:
      'Type: electronic, weighing limit: 10.0kg, Measurement accuracy: 1.0g, Calorie counter: Yes,Color: White',
    rating: 5,
    category: 'Appliances',
    link: 'https://kaspi.kz/shop/p/generic-sf-400-102531445/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 3,
    name: 'Blender SM-7700 silver',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h78/he6/81315957440542.png?format=gallery-large',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h78/he6/81315957440542.png?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h78/he6/81315957440542.png?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h78/he6/81315957440542.png?format=gallery-medium',
    ],
    price: 8749,
    description:
      'Type: Stationary, Power: 1000.0W, Control: Mechanical, Number of speeds: 3, Chopper: Yes, Color: Silver',
    rating: 5,
    category: 'Appliances',
    link: 'https://kaspi.kz/shop/p/sm-7700-serebristyi-110902818/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 4,
    name: 'Vacuum cleaner Deerma DX700 white',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/hdb/h2f/63803859566622.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h20/he1/63803865792542.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/had/h34/63803868741662.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h2e/h83/63803872280606.jpg?format=gallery-medium',
    ],
    price: 19147,
    description:
      'Type: vertical, cleaning: dry, Dust collector type: cyclone filter, Power consumption: 600.0W, Power source: mains, color: White',
    rating: 5,
    category: 'Appliances',
    link: 'https://kaspi.kz/shop/p/deerma-dx700-belyi-3701383/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 5,
    name: 'Smartphone Apple iPhone 13 128Gb white',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/hc9/h90/64209083007006.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h8f/hce/64209121476638.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h4b/h84/64209123573790.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/hba/hc4/64209127243806.jpg?format=gallery-medium',
    ],
    price: 299959,
    description:
      'nFC Technology: Yes,color: white,screen Type: OLED, Super Retina XDR,diagonal: 6.1 inch,rAM size: 4 GB',
    rating: 4.5,
    category: 'Smartphones',
    link: 'https://kaspi.kz/shop/p/apple-iphone-13-128gb-belyi-102298420/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 6,
    name: 'Smartphone Apple iPhone 14 128Gb black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h98/h2b/64400497737758.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hc8/h0b/64400500097054.jpg?format=gallery-large',
      'https://resources.cdn-kaspi.kz/img/m/p/h6e/h4f/64400506159134.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h04/h5d/64400509108254.jpg?format=gallery-medium',
    ],
    price: 330386,
    description:
      'nFC Technology: Yes color: Black screen Type: OLED, Super Retina XDR display diagonal: 6.1 inch rAM size: 6 GB',
    rating: 5,
    category: 'Smartphones',
    link: 'https://kaspi.kz/shop/p/apple-iphone-14-128gb-chernyi-106363023/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 7,
    name: 'Smartphone Xiaomi Redmi Note 10 Pro 8GB/256GB Grey',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h94/h74/64487156645918.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hb2/h0e/64487161692190.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h0a/h82/64487159398430.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h6d/h29/64487164772382.jpg?format=gallery-large',
    ],
    price: 139990,
    description:
      'nFC Technology: Yes,color: grey,screen Type: Color AMOLED, Touch,diagonal: 6.67 inch,rAM size: 8 GB',
    rating: 5,
    link: 'https://kaspi.kz/shop/p/xiaomi-redmi-note-10-pro-8-gb-256-gb-seryi-107221005/?c=750000000',
    category: 'Smartphones',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 8,
    name: 'Smartphone Samsung Galaxy A13 4GB/128GB Black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h1c/hac/64381277929502.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hf3/hf9/64381281107998.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h01/h53/64381288874014.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h46/h05/64381298704414.jpg?format=gallery-medium',
    ],
    price: 195000,
    description:
      'nFC Technology: Yes color: Black screen Type: PLS TFT LCD Touch, Multi-touch diagonal: 6.6 inch rAM size: 4 GB',
    rating: 5,
    category: 'Smartphones',
    link: 'https://kaspi.kz/shop/p/samsung-galaxy-a13-4-gb-128-gb-chernyi-104253279/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 9,
    name: 'Notebook Lenovo IdeaPad 1 14IGL05 81VU00H3RU grey',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/hc1/h8e/67940461805598.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h8a/hf7/67940462329886.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h01/hfb/67940462854174.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h37/h92/67940463378462.jpg?format=gallery-medium',
    ],
    price: 149799,
    description:
      'display diagonal: 14 inch rocessor: Intel Celeron N4020 graphics: Intel UHD Graphics 600 rAM size: 4 G hard Drive Type: SSD storage Capacity: 128 GB',
    rating: 5,
    category: 'Laptops',
    link: 'https://kaspi.kz/shop/p/lenovo-ideapad-1-14igl05-81vu00h3ru-seryi-108464874/?c=750000000#!/item',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 10,
    name: 'Notebook ASUS TUF Gaming A15 FA506ICB-HN105 90NR0667-M00BL0 black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h0c/hbc/66995169886238.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h6d/hc5/66995170541598.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/hd1/he8/66995171131422.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h0c/hbc/66995169886238.jpg?format=gallery-medium',
    ],
    rating: 5,
    price: 679990,
    description:
      'display diagonal: 15.6 inch processor: AMD Ryzen 5 4600H graphics: NVIDIA GeForce RTX 3050 rAM size: 8 GB hard Drive Type: SSD',
    category: 'Laptops',
    link: 'https://kaspi.kz/shop/p/asus-tuf-gaming-a15-fa506icb-hn105-90nr0667-m00bl0-chernyi-108093785/?c=750000000#!/item',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 11,
    name: 'Simple Shop Laptop TableT 8',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h2c/h01/63953967611934.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h35/h50/63953969414174.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/he0/h60/63953972658206.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h3f/h2f/63953975869470.jpg?format=gallery-medium',
    ],
    price: 7198,
    description:
      'Type: active cooling, laptop diagonal: 15.6, number of fans: 2, backlight: No',
    rating: 4.6,
    link: 'https://kaspi.kz/shop/p/simpleshop-laptop-table-t8-102568472/?c=750000000',
    category: 'Laptops',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 12,
    name: 'Laptop Apple MacBook Air 13 MGN93 silver',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h9a/h35/64082972704798.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h9b/hed/64082975653918.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/hf8/he3/64082978111518.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/hf9/h31/64082981224478.jpg?format=gallery-medium',
    ],
    rating: 5,
    price: 419999,
    description:
      'Screen diagonal: 13.3 inch, processor: Apple M1, video card: Apple M1, RAM size: 8.0 GB, hard drive type: SSD, total storage capacity: 256.0 GB',
    category: 'Laptops',
    link: 'https://kaspi.kz/shop/p/apple-macbook-air-13-mgn93-serebristyi-100798912/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 13,
    name: 'TV Samsung UE43T5300AUXCE 109 cm black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h70/hca/63880820457502.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/h4f/h4d/63880826617886.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h4b/h75/63880828715038.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h49/h20/63880832253982.jpg?format=gallery-medium',
    ],
    price: 138413,
    description:
      'type: LED TV diagonal: 43 inch resolution: 1920x1080 hD Support: 1080p Full HD smart TV Technology: Yes wi-Fi: Yes',
    rating: 5,
    category: 'TV',
    link: 'https://kaspi.kz/shop/p/samsung-ue43t5300auxce-109-sm-chernyi-100182013/?c=750000000#!/item',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 14,
    name: 'TV Leadbros S01M04D17SMART32 black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h8e/h85/80366137278494.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/he6/hb8/80366650753054.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h24/h8a/80366651015198.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/he0/hde/80366651539486.jpg?format=gallery-medium',
    ],
    price: 54900,
    description:
      'type: LED TV, diagonal: 32.0 inch, resolution: 1366x768, HD support: 1080p Full HD, Smart TV technology: Yes, Wi-Fi: Yes, inputs: AV, ,HDMI, ,SCART, ,USB, ,Bluetooth',
    rating: 4.5,
    category: 'TV',
    link: 'https://kaspi.kz/shop/p/leadbros-s01m04d17smart32-chernyi-109893243/?c=750000000',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 15,
    name: 'TV Xiaomi TV P1 32 L32M6-6ARG 81 cm black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/hf0/h73/64192946405406.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hc7/hef/64192950763550.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h02/ha4/64192953024542.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h58/h2d/64192955744286.jpg?format=gallery-medium',
    ],
    price: 118990,
    description:
      'type: LED TV diagonal: 32 inch resolution: 1366x768 hd Support: 720p HD smart TV Technology: Yes wi-Fi: Yes',
    rating: 4,
    category: 'TV',
    link: 'https://kaspi.kz/shop/p/xiaomi-tv-p1-32-l32m6-6arg-81-sm-chernyi-103039169/?c=750000000#!/item',
    IsShown: false,
    likeCount: 0,
  },

  {
    id: 16,
    name: 'TV Yasin 32G7 81 cm black',
    image:
      'https://resources.cdn-kaspi.kz/img/m/p/h2d/h0c/64366743879710.jpg?format=gallery-medium',
    images: [
      'https://resources.cdn-kaspi.kz/img/m/p/hf6/h99/64366745649182.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/hb2/h44/64366747877406.jpg?format=gallery-medium',
      'https://resources.cdn-kaspi.kz/img/m/p/h2d/h0c/64366743879710.jpg?format=gallery-medium',
    ],
    price: 69767,
    description:
      'type: LED TV diagonal: 43 inch resolution: 1920x1080 hD Support: 1080p Full HD smart TV Technology: Yes wi-Fi: Yes',
    rating: 4,
    category: 'TV',
    link: 'https://kaspi.kz/shop/p/yasin-32g7-81-sm-chernyi-103489358/?c=750000000#!/item',
    IsShown: false,
    likeCount: 0,
  },
];

/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at https://angular.io/license
*/
